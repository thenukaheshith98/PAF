package com.paf.patient.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("api")
public class HelthCareApp extends Application {

}
